package com.example.signup.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.signup.entity.User;
import com.example.signup.exception.ResourceNotFoundException;
import com.example.signup.repository.UserRepo;

@Service
public class CustomUserService implements UserDetailsService {
	
	@Autowired
	UserRepo userRepo;
	
	

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = this.userRepo.findByEmailId(username).orElseThrow(()->new ResourceNotFoundException("User", "emailId : "+username,0));
				return user;
	}
	
	

}
